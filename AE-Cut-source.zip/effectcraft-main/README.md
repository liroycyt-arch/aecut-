<p align="center"><img src="assets/brand/aecut-logo.png" width="140" alt="AE Cut"></p>

# AE Cut

תוכנת עריכת וידאו ואפקטים בעברית לווינדוס. ממשק כתום־שחור, ציר זמן רב־שכבתי, פריימים מרכזיים, אפקטים וייצוא.

**כל הקרדיטים: Liroy C**

## הורדת קובץ ההתקנה
1. לשונית **Actions** ▸ **Build AE Cut Setup** ▸ **Run workflow**.
2. אחרי סיום הריצה (בערך 30–60 דקות בפעם הראשונה) לחץ על הריצה והורד את **AE-Cut-Setup** מאזור **Artifacts**.
3. פתח את הזיפ והפעל את `AE Cut Setup.exe`.

אם הריצה נכשלה, הורד את **build-log** ושלח אותו.

## מבנה
`apps/effectcraft` האפליקציה · `crates/` המנוע, האפקטים, הרינדור והממשק · `packaging/windows/inno` המתקין.

## רישיונות
ראה `LICENSES-AECUT.txt` ואת `docs/licenses`.
