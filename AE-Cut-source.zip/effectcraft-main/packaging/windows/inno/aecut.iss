﻿; AE Cut Setup - Inno Setup script. Built by .github/workflows/build-windows-setup.yml
; Compile: iscc /DMyAppVersion=0.8.0 aecut.iss   (expects ..\..\..\stage\ with the files below)
#ifndef MyAppVersion
  #define MyAppVersion "0.8.0"
#endif
#define MyAppName "AE Cut"
#define MyAppPublisher "Liroy C"
#define MyAppExe "AE Cut.exe"

[Setup]
AppId={{B7D2E1A4-6C3F-4A59-9E0B-0AEC07000001}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
AppCopyright=Copyright (c) 2026 Liroy C
DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
OutputDir=..\..\..\dist
OutputBaseFilename=AE Cut Setup
SetupIconFile=aecut.ico
WizardImageFile=wizard-large.bmp
WizardSmallImageFile=wizard-small.bmp
UninstallDisplayIcon={app}\{#MyAppExe}
UninstallDisplayName={#MyAppName}
Compression=lzma2/max
SolidCompression=yes
ArchitecturesAllowed=x64
ArchitecturesInstallIn64BitMode=x64
WizardStyle=modern
ChangesAssociations=yes
PrivilegesRequiredOverridesAllowed=dialog
LicenseFile=..\..\..\stage\LICENSES.txt

[Languages]
Name: "hebrew"; MessagesFile: "Hebrew.isl"

[CustomMessages]
hebrew.ExtraTasks=קיצורי דרך ושיוך קבצים
hebrew.TaskDesktop=צור קיצור דרך בשולחן העבודה
hebrew.TaskAssoc=שייך קבצי פרויקט (.lcproj) ל-AE Cut
hebrew.LaunchApp=הפעל את AE Cut עכשיו

[Tasks]
Name: "desktopicon"; Description: "{cm:TaskDesktop}"; GroupDescription: "{cm:ExtraTasks}"
Name: "assoc"; Description: "{cm:TaskAssoc}"; GroupDescription: "{cm:ExtraTasks}"

[Files]
Source: "..\..\..\stage\AE Cut.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\..\..\stage\setup.marker"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\..\..\stage\LICENSES.txt"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\..\..\stage\licenses\*"; DestDir: "{app}\licenses"; Flags: ignoreversion recursesubdirs createallsubdirs skipifsourcedoesntexist
Source: "..\..\..\stage\fonts\*"; DestDir: "{app}\fonts"; Flags: ignoreversion recursesubdirs createallsubdirs skipifsourcedoesntexist

[Icons]
Name: "{autoprograms}\{#MyAppName}"; Filename: "{app}\{#MyAppExe}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExe}"; Tasks: desktopicon

[Registry]
Root: HKA; Subkey: "Software\Classes\.lcproj"; ValueType: string; ValueName: ""; ValueData: "AECut.Project"; Flags: uninsdeletevalue; Tasks: assoc
Root: HKA; Subkey: "Software\Classes\AECut.Project"; ValueType: string; ValueName: ""; ValueData: "AE Cut project"; Flags: uninsdeletekey; Tasks: assoc
Root: HKA; Subkey: "Software\Classes\AECut.Project\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\{#MyAppExe},0"; Tasks: assoc
Root: HKA; Subkey: "Software\Classes\AECut.Project\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\{#MyAppExe}"" ""%1"""; Tasks: assoc
Root: HKA; Subkey: "Software\Classes\.lcpreset"; ValueType: string; ValueName: ""; ValueData: "AECut.Preset"; Flags: uninsdeletevalue; Tasks: assoc
Root: HKA; Subkey: "Software\Classes\AECut.Preset"; ValueType: string; ValueName: ""; ValueData: "AE Cut preset"; Flags: uninsdeletekey; Tasks: assoc
Root: HKA; Subkey: "Software\Classes\AECut.Preset\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\{#MyAppExe}"" ""%1"""; Tasks: assoc

[Run]
Filename: "{app}\{#MyAppExe}"; Description: "{cm:LaunchApp}"; Flags: nowait postinstall skipifsilent
