//! AE Cut has no online links: no website, no community server, no repository.

pub const APP_NAME: &str = "AE Cut";
pub const APP_SLUG: &str = "effectcraft";
